package com.routesearch.route;



import java.util.ArrayList;

public class Prune {
	// ͼ�����ݴ洢
	
	public Integer[][] graphContentArrayPruneArray;
	public Integer[] begEndSet;
	public Integer[] assignMiddleVertexSet;
	
	public void getPrune(String graphContent, String condition)
	{
	
	String[] graphContentSplitNewLine = graphContent.split("\\\n");
	int graphContentRow = graphContentSplitNewLine.length;
	int graphContentColumn=4;
	Integer[][] graphContentArray = new Integer[graphContentRow][graphContentColumn];
	for (int i = 0; i < graphContentRow; i++) {
		String[] s = graphContentSplitNewLine[i].split("\\,");
		for (int j = 0; j < graphContentColumn; j++) {
			graphContentArray[i][j] = Integer.parseInt(s[j]);
		}
	}

	// ·�������ݴ洢
	String[] conditionSplitNewLine = condition.split("\\\n");

	int conditionColumn = 3;
	// System.out.println(conditionColumn);
	begEndSet = new Integer[2];// ���ϰ��������յ�
	String[] c = conditionSplitNewLine[0].split("\\,");
	for (int j = 0; j < conditionColumn - 1; j++) {
		begEndSet[j] = Integer.parseInt(c[j]);
		// System.out.println(begEndSet[j]);
	}
	
	// �õ�ָ�����м�ڵ㼯
	String[] d = c[conditionColumn - 1].split("\\|");
	int assignVertexSetLength = d.length;
	assignMiddleVertexSet = new Integer[assignVertexSetLength];
	for (int i = 0; i < assignVertexSetLength; i++) {
		assignMiddleVertexSet[i] = Integer.parseInt(d[i]);
		// System.out.println(assignMiddleVertexSet[i]);
	}
	
	// �õ������յ�
	int[] beginPointSet = new int[graphContentRow];

	// ����ͼ�е���㼯
	for (int i = 0; i < graphContentRow; i++) {
		beginPointSet[i] = graphContentArray[i][1];
		// System.out.println(allId[i]);
	}
	// �õ����е�Id��
	int[] allId = new int[2 * graphContentRow];
	for (int i = 0; i < graphContentRow; i++) {
		allId[i] = graphContentArray[i][1];
	}
	for (int i = graphContentRow; i < 2 * graphContentRow; i++) {
		allId[i] = graphContentArray[i - graphContentRow][2];
	}
	QuickSort.quickSort(beginPointSet);// ��������
	QuickSort.quickSort(allId);// ��������

	// �õ����ж��������
	FindNodeKind allVertex = new FindNodeKind(2 * graphContentRow);
	allVertex.calculateVertexIdAndVertexKind(allId);
	int[] allVertexId = allVertex.getVertexId();
	int allVertexKind = allVertex.getVertexKind();
	
	// �õ���㼯������
	FindNodeKind a = new FindNodeKind(graphContentRow);
	a.calculateVertexIdAndVertexKind(beginPointSet);
//	System.out.println("   ");
	int startIdVertexKind = a.getVertexKind();//
	int[] startId = a.getVertexId();
	ArrayList<Integer> NodeSet = new ArrayList<Integer>();
	for (int i = 0; i < allVertexKind; i++) {
		NodeSet.add(allVertexId[i]);
	}
	
	// �����е㼯�д�������ʼ��Ļ�����ô��Щ��ĳ��ȾͲ�Ϊ0
	for (int i = 0; i < startIdVertexKind; i++) {
		for (int j = 0; j < allVertexKind; j++) {
			if (startId[i] == allVertexId[j]) {
				NodeSet.set(j, -10);// Ϊ-10�ĵ��ǳ��Ȳ�Ϊ0�ĵ�
				continue;
			}
		}
	}
	
	// �ҳ�����ȵ㼯
	ArrayList<Integer> zeroOutdegreeNodeSet = new ArrayList<Integer>();
	for (int i = 0; i < allVertexKind; i++) {
		if ((NodeSet.get(i) >= 0) && (NodeSet.get(i) != begEndSet[1])) {
			zeroOutdegreeNodeSet.add(NodeSet.get(i));
		}
	}

	// ��ԭͼ���м�֦
	PruneGraph graphContentArrayPrune = new PruneGraph(graphContentRow);
	graphContentArrayPruneArray = graphContentArrayPrune.getpruneGraph(zeroOutdegreeNodeSet,
			graphContentArray, assignMiddleVertexSet, assignVertexSetLength);
	}
	
	public Integer[][] getGraphContentArrayPruneArray()
	{
		return graphContentArrayPruneArray;
	}
	
	public Integer[] getBegEndSet()
	{
		return begEndSet;
	}
	
	public Integer[] getAssignMiddleVertexSet()
	{
		return assignMiddleVertexSet;
	}
	}

