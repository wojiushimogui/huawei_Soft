package com.routesearch.route;


public class FindNodeKind {
   int vertexKind=1;
 // int vertexSame=0;
  int graphContentRow;
  int[] vertexId;

 public FindNodeKind(int a)
 {
	 graphContentRow=a;
 }
 
  //public  void calculateDegree(int[] pointSet)
 public void calculateVertexIdAndVertexKind(int[] pointSet)
  {
	  // outDegree=new int[graphContentRow];
   vertexId=new int[graphContentRow];
   
   
   
  for (int i=0;i<graphContentRow-1;i++)
  {  
	 // vertexId[i]=-1;
  	vertexId[i]=-1;
  	if (pointSet[i+1]>pointSet[i])
  	{
  		
  		vertexKind=vertexKind+1;
  		//vertexSame=1;  
  		vertexId[vertexKind-1]=pointSet[i+1];
  	}
  	else
  	{		
  		vertexId[vertexKind-1]=pointSet[i];//���id��
  	//	outDegree[vertexKind-1]=vertexSame+1;//��ͬ�ڵ��ID���ж��ٸ�
  		vertexId[vertexKind]=i;
  		//vertexSame=vertexSame+1;
  	}	 	
  }
  vertexId[0]=0;
  vertexId[vertexKind-1]=pointSet[graphContentRow-1];//��ֹ�����û���ظ�
  }
  
  public  int getVertexKind()
  { 
	return  vertexKind; //�����Ŵ�0��ʼ����
  }
  
 
  
  public  int[] getVertexId()
  {
	  return vertexId;
  }
  
//  public  int[] getOutDegree()
//  {
//	  return  outDegree;
  }
 


