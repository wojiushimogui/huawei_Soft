package com.routesearch.route;

import java.util.ArrayList;

public class PruneArray {
	//System.out.println(zeroOutdegreeNodeSet.get(0));
	int graphContentRow;
	
	//int deteleEdge=0;
	
	public  PruneArray(int a)
	{
		graphContentRow=a;

	}
	
	public Integer[][] getGraphContentArrayPrune(ArrayList<Integer> zeroOutdegreeNodeSet,Integer[][] graphContentArray)
	{
	for (int i=0;i<graphContentRow;i++)
	{
		//System.out.println(graphContentRow);
		int l=zeroOutdegreeNodeSet.size();
	for (int j=0;j<l;j++)
	{
		if (graphContentArray[i][2]==zeroOutdegreeNodeSet.get(j))
		{
			//deteleEdge=deteleEdge+1;
			//System.out.println("ta ta ta");
			for (int m=0;m<graphContentRow-i-1;m++)
			{
				//System.out.println(i);
				graphContentArray[i+m][0]=graphContentArray[i+m+1][0];
				graphContentArray[i+m][1]=graphContentArray[i+m+1][1];
				graphContentArray[i+m][2]=graphContentArray[i+m+1][2];
				graphContentArray[i+m][3]=graphContentArray[i+m+1][3];
			}
			graphContentRow=graphContentRow-1;
			i=i-1;
		//	System.out.println(graphContentRow);
		}
	}
	}


//�����֦�������
	Integer[][] graphContentArrayPrune=new Integer[graphContentRow][4];
for (int i=0;i<graphContentRow;i++)
{
	graphContentArrayPrune[i][0]=graphContentArray[i][0];
	graphContentArrayPrune[i][1]=graphContentArray[i][1];
	graphContentArrayPrune[i][2]=graphContentArray[i][2];
	graphContentArrayPrune[i][3]=graphContentArray[i][3];
	
}
return graphContentArrayPrune;

//
//System.out.println(begEndSet[0]);
//System.out.println(assignVertexSet[0]);
}
	
//	public int[][] getGraphContentArrayPrune()
//	{
//		return graphContentArrayPrune;
//	}

}
